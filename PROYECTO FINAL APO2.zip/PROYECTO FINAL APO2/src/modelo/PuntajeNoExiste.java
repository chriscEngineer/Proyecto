package modelo;

public class PuntajeNoExiste extends Exception{
	//CONSTANTES 
	
	
	//RELACIONES
	
	//ATRIBUTOS
	
	
	/*
	 * METODO CONSTRUCTOR DE LA CLASE
	 */
	public PuntajeNoExiste(String msj) {
		// TODO Auto-generated constructor stub
		super(msj);
	}
	
	
	/*
	 * METODOS DAR Y MODIFICAR DE LA CLASE
	 */
	
	
	
	/*
	 * METODOS PARA CUMPLIR CON LOS REQUERIMIENTOS
	 */

}
