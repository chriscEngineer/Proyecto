package modelo;

public class EstiloIcorrecto extends Exception {
	
	public EstiloIcorrecto(String msj) {
		super("Estilo Icorrecto.");
	}

}
