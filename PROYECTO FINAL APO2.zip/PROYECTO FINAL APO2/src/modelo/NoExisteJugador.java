package modelo;

public class NoExisteJugador extends Exception{
	
		public NoExisteJugador(String msj) {
			super(msj);
		}

}
