package modelo;


public class PuntajeExiste extends Exception {
	
	//CONSTANTES 
	
	
	//RELACIONES
	
	//ATRIBUTOS
	
	
	/*
	 * METODO CONSTRUCTOR DE LA CLASE
	 */
	public PuntajeExiste(String msj) {
		super(msj);
	}
	
	
	/*
	 * METODOS DAR Y MODIFICAR DE LA CLASE
	 */
	
	
	
	/*
	 * METODOS PARA CUMPLIR CON LOS REQUERIMIENTOS
	 */
	


}
