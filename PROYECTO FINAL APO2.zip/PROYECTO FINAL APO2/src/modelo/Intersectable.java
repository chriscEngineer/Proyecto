package modelo;

public interface Intersectable {

	
	public boolean interseccion(Bird c);
}
