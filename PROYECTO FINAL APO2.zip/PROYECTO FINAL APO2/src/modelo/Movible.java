package modelo;

public interface Movible {
	
	public void mover();
}
