package modelo;

public interface Puntable {
	
	public int puntos(int c);

}
